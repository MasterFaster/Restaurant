package sample.People;

/**
 * Created by Master Faster on 05.12.2016.
 */
public class OccasionalClient extends Client {

}
