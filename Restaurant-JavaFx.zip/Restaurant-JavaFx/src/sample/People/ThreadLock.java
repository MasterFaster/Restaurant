package sample.People;

import java.io.Serializable;

/**
 * Created by Master Faster on 22.01.2017.
 * Important class to lock Thread (to make Thread to wait for signal)
 */
public class ThreadLock implements Serializable {
}
